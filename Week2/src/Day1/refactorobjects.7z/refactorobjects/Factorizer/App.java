package Day1.refactorobjects.Factorizer;

public class App {
    public static void main(String[] args) {
       Factorizer factorizer = new Factorizer();

       int number = Factorizer.readValue("What number would you like to factor?");

        System.out.println("The factors of " + number + " are:");

        factorizer.getFactors(number);

        factorizer.checkAndPrintReport(number);
    }
}
