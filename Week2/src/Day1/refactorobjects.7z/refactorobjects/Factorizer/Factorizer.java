package Day1.refactorobjects.Factorizer;

import java.util.Scanner;

public class Factorizer {
    private static Scanner sc = new Scanner(System.in);
    private int counter = 0;
    private int numberOfFactors = 0;
    private boolean isPerfect = false;


    public static int readValue (String prompt) {
        int number = 0;
        try {
            System.out.println(prompt);
            number = Integer.parseInt(sc.nextLine());

        }catch(Exception e){
            System.out.println("Invalid input for number. " + e);
            System.exit(0);
        }

        return number;
    }


    public void getFactors(int number) {
        for (int i = 1; i <= number; i++) {
            if (number % i == 0) {
                System.out.print(i + " ");

                counter++;
                numberOfFactors += i;

                if (number == (numberOfFactors-number)){
                    isPerfect = true;
                }
            }

        }
    }

    public void checkAndPrintReport(int number) {
        System.out.println("\n" + number + " has " + counter + " factors.\n");

        //check if Perfect
        if (isPerfect){
            System.out.println(number + " is a perfect number.");
        } else {
            System.out.println(number + " is not a perfect number.");
        }
        //check if Prime
        if (counter < 3) {
            System.out.println(number + " is a prime number.");
        } else {
            System.out.println(number + " is not a prime number");
        }
    }

}
