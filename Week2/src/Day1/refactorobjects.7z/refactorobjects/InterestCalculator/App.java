package Day1.refactorobjects.InterestCalculator;


public class App {
    public static void main(String[] args) {
        InterestCalculator interestCalculator = new InterestCalculator();

        System.out.println("Calculating...");

        interestCalculator.formattingAndPrintingReport();

    }
}
