package Day1.refactorobjects.InterestCalculator;


import Day1.refactorobjects.Factorizer.Factorizer;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.util.Scanner;

public class InterestCalculator {
    private static Scanner sc = new Scanner(System.in);
    private int counterYears = 1;
    private double result = 0;

    public double initialAmountToInvest = InterestCalculator.readValue("How much do you want to invest?");

    //Showing that we can call static methods from other classes in another packages.
    private int yearsInvesting = Factorizer.readValue("How many years are you investing?");

    private double annualRate = InterestCalculator.readValue("What is the annual interest rate % growth?");

    private double calcAnnualGrow(double percent, double currentAmount) {

        for (int i = 1; i < 5; i++) {
            currentAmount = currentAmount * (1 + (percentQuarterly(percent) / 100));
        }
        return currentAmount;
    }

    private double percentQuarterly (double percent) {
        return percent / 4;
    }


    //Gets user input (double)
    public static double readValue (String prompt) {

        double number = 0;
        try {
            System.out.println(prompt);
            number = Double.parseDouble(sc.nextLine());

        }catch(Exception e){
            System.out.println("Invalid input for number. " + e);
            System.exit(0);
        }

        return number;
    }


    public void formattingAndPrintingReport() {
        while(yearsInvesting > 0) {
            System.out.println("Year " + counterYears + ":");

            BigDecimal finalResult = BigDecimal.valueOf(result = calcAnnualGrow(annualRate, initialAmountToInvest));
            finalResult = finalResult.setScale(2, RoundingMode.HALF_UP);

            System.out.println("Began with $"+ initialAmountToInvest);
            System.out.println("Earn $" + (BigDecimal.valueOf(result - initialAmountToInvest).setScale(2,RoundingMode.HALF_UP)));
            System.out.println("Ended with $" + finalResult + "\n");

            initialAmountToInvest = Double.parseDouble(String.valueOf(finalResult));

            yearsInvesting--;
            counterYears++;
        }
    }


}
