package Day1.refactorobjects.LuckySevens;

public class App {
    public static void main(String[] args) {
       LuckySevens luckySevens = new LuckySevens();
        luckySevens.rollDicesAndPlay();
    }
}
