package Day1.refactorobjects.LuckySevens;

import Day1.refactorobjects.Factorizer.Factorizer;

import java.util.Random;
import java.util.Scanner;

public class LuckySevens {
    private static Scanner sc = new Scanner(System.in);
    Random dice1 = new Random();
    Random dice2 = new Random();
    private int dice1Number = 0;
    private int dice2Number = 0;
    private int numberOfRolls = 0;
    private int currentAmountOfMoney = 0;
    private int currentNumberOfRools = 0;
    private int amountWhileWinning = 0;

    public int initialAmountOfMoney = Factorizer.readValue("How many dollars do you have?");

    public void rollDicesAndPlay() {
        try {
            currentAmountOfMoney = initialAmountOfMoney;
            while (currentAmountOfMoney >= 0) {
                dice1Number = dice1.nextInt(7);
                dice2Number = dice2.nextInt(7);
                numberOfRolls++;
                if (dice1Number + dice2Number == 7) {
                    currentAmountOfMoney += 4;
                    if (currentAmountOfMoney > initialAmountOfMoney ) {
                        currentNumberOfRools = numberOfRolls;
                        amountWhileWinning = currentAmountOfMoney;
                    }
                } else {
                    currentAmountOfMoney-= 1;
                    if (currentAmountOfMoney == 0) {
                        System.out.println("You are broke after "+ numberOfRolls +  " rolls.");
                        if (amountWhileWinning > initialAmountOfMoney) {
                            System.out.println("You should have quit after " +currentNumberOfRools +" rolls when you had $"+ amountWhileWinning + ".");
                        }
                        else {
                            System.out.println("Sorry dude, you got no chance on this game...");
                        }
                    }
                }
            }
        } catch (Exception e) {
            System.out.println("Invalid input for a number. " + e);
        }
    }








}
