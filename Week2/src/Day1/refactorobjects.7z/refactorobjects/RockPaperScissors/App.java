package Day1.refactorobjects.RockPaperScissors;

public class App {
    public static void main(String[] args) {
        RockPaperScissors game = new RockPaperScissors();

        game.loopingRoundsAndChooseWeapon(RockPaperScissors.rounds,RockPaperScissors.softWeapon,RockPaperScissors.compSoftWeapon,RockPaperScissors.rSoftWeapon); //using static variables, I could use getters instead
        game.printResults();
        game.rematchLoop();
    }
}
