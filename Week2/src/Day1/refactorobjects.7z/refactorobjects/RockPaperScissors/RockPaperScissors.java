package Day1.refactorobjects.RockPaperScissors;

import java.util.Random;
import java.util.Scanner;

public class RockPaperScissors {
    private static Scanner sc = new Scanner(System.in);
    public static Random rSoftWeapon = new Random();
    private int userVictories = 0;
    private int compVictories = 0;
    private int ties = 0;
    private boolean playAgain = false;
    public static int compSoftWeapon = 0;
    public static int softWeapon = 0;

    //Begins...
     public static int rounds = readValue("Let's play Rock, Paper, Scissor!\nHow many rounds do you want to play?");

    //Getting the user input
    public static int readValue (String prompt) {
        int userInputRounds = 0;
        try {
            System.out.println(prompt);
            userInputRounds = Integer.parseInt(sc.nextLine());
            if (userInputRounds > 10 || userInputRounds <= 0)
                throw new Exception();
        }catch(Exception e){
            System.out.println("Invalid input for number. " + e);
            System.exit(0);
        }
        return userInputRounds;
    }

    //Check for input Choice: Rock, Paper, Scissors
    public void checkValue (int softWeapon) {
        while (softWeapon > 3 || softWeapon < 1){
            System.out.println("Input is out of range");
            readValue("Choose between: 1 = Rock, 2 = Paper, 3 = Scissors");
        }
    }

    //Looping over the game
    public void loopingRoundsAndChooseWeapon(int rounds, int softWeapon, int compSoftWeapon, Random rSoftWeapon){
        for (int i = 1; i <= rounds; i++) {
            softWeapon = readValue("Choose between: 1 = Rock, 2 = Paper, 3 = Scissors");
            checkValue(softWeapon);
            System.out.println("You chose: " +softWeapon + "\n");
            compSoftWeapon = rSoftWeapon.nextInt(3)+1;
            System.out.println("Computer chose: " +compSoftWeapon + "\n");
            shout(softWeapon,compSoftWeapon);
        }
    }

    //Comparing softWeapons
    public void shout(int userSoftWeapon, int compSoftWeapon) {
        if (userSoftWeapon == compSoftWeapon) {
            System.out.println("There is a TIE!\n");
            ties++;
        } else if ((userSoftWeapon != 3) && userSoftWeapon > compSoftWeapon) {
            System.out.println("YOU WON! NICE ONE...\n");
            userVictories++;
        } else if ((userSoftWeapon == 1) && compSoftWeapon ==3) {
            System.out.println("YOU WON! NICE ONE...\n");
            userVictories++;
        } else if ((userSoftWeapon == 3) && compSoftWeapon ==2) {
            System.out.println("YOU WON! NICE ONE...\n");
            userVictories++;
        }
        else {
            System.out.println("HA HA HA... I WON! \n");
            compVictories++;
        }
    }


    //Printing results
    public void printResults(){
        System.out.println("User victories: " + userVictories + "\n");
        System.out.println("Computer victories: " + compVictories + "\n");
        System.out.println("Ties: " + ties + "\n");
        checkWinner();
    }

    //Checking the winner
    public void checkWinner() {
        if (userVictories == compVictories) {
            System.out.println("We Tie the match! " + userVictories + " to " + compVictories + "\n");
        } else if (userVictories > compVictories) {
            System.out.println("CONGRATS YOU WON: " + userVictories + " to "+ compVictories+ " Ties do not count.\n");
        } else {
            System.out.println("I WON THE MATCH " + compVictories + " to " + userVictories + " Ties do not count.\n");
        }
    }


    //REMATCH
    public void rematchLoop() {
        while (rematch("Do you want to play again: yes or no?")){
            userVictories = 0;
            compVictories = 0;
            ties = 0;
            loopingRoundsAndChooseWeapon(rounds,softWeapon,compSoftWeapon,rSoftWeapon);
            printResults();
        }
    }

    //Offering rematch
    public boolean rematch(String prompt) {
        String again = "";
        try {
            System.out.println(prompt);
            again = sc.nextLine();
            if (again.equals("yes")) {
                playAgain = true;
                rounds = readValue("How many rounds do you want to play?");
            } else {
                System.out.println("Ok, thanks for playing!");
                sc.close();
                System.exit(0);
            }

        }catch(Exception e){
            System.out.println("Invalid input. " + e);
            System.exit(0);
        }
        return playAgain;
    }


}
